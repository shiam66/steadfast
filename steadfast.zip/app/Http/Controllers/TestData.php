<?php

namespace App\Http\Controllers;

use App\Services\SteadfastService;
use Illuminate\Http\Request;

class TestData extends Controller
{
    protected $steadfast;

    public function __construct(SteadfastService $steadfast)
    {
        $this->steadfast = $steadfast;
    }

    public function postData(Request $request)
    {
        $data = $this->steadfast->post('/endpoint', $request->all()); // Update with actual endpoint
        return response()->json($data);
    }

    public function create(Request $request)
    {
        $request->validate([
            'name' => 'required'
        ]);

        // return back()->with('message','data has been created successfully.');

        $data = 

        [

            'invoice' => 'fddf512',

            'recipient_name' => 'Shiam Hossain',

            'recipient_phone' => '01981893135',

            'recipient_address' => 'Fla# A1,House# 17/1, Road# 3/A, Dhanmondi,Dhaka-1209',

            'cod_amount' => 1000,

            'note' => 'Handle with care'

        ];


        $dataf = $this->steadfast->post('/create_order', $data); // Update with actual endpoint
        return response()->json($dataf);


        //$data = $this->steadfast->get('/endpoint');
       // return dd($data);

        //return view('data-view', compact('data'));
        //return view('data-view', compact('data'));

        //$response = SteadfastCourier::placeOrder($orderData);

        //return $response->json($orderData);
       // return dd($response);
        //die();
        
        //TestData::create($request->post());

        //Session::put('message');

        //return back()->with('message','data has been created successfully.');
 
        //return redirect()->route('students.index')->with('success','Student has been created successfully.');
    }

    public function fetchData()
    {
        $data = $this->steadfast->get('/endpoint');
        return view('data-view', compact('data'));
    }
}
