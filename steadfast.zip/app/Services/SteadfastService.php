<?php
namespace App\Services;

use GuzzleHttp\Client;

class SteadfastService
{
    protected $client;
    protected $apiUrl;
    protected $apiKey;
    protected $apiSecretKey;

    public function __construct()
    {
        $this->client = new Client();
        $this->apiUrl = config('services.steadfast.url');
        $this->apiKey = config('services.steadfast.key');
        $this->apiSecret = config('services.steadfast.secret');
    }

    public function get($endpoint, $params = [])
    {
        $response = $this->client->request('GET', $this->apiUrl . $endpoint, [
            'headers' => [
                'Api-Key' => $this->apiKey,
                'Secret-Key' => $this->apiSecret,
                'Accept'        => 'application/json',
            ],
            'query' => $params,
        ]);

        return json_decode($response->getBody(), true);
    }

    public function post($endpoint, $data = [])
    {
        // $response = $this->client->request('POST', $this->apiUrl . $endpoint, [
        //     'headers' => [
        //         'Api-Key' => $this->apiKey,
        //         'Secret-Key' => $this->apiSecret,
            
        //         'Content-Type'  => 'application/json',
        //     ],
        //     'json' => $data,
        // ]);

        // return json_decode($response->getBody(), true);

        try {
            $response = $this->client->request('POST', $this->apiUrl . $endpoint, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->apiKey,
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                ],
                'json' => $data,
            ]);

            return json_decode($response->getBody(), true);
        } catch (RequestException $e) {
            // Log error or handle exception
            return ['error' => $e->getMessage()];
        }
    }

    // Add other methods (PUT, DELETE) as needed
}
